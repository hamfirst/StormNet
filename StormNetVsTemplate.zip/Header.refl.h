#pragma once

#include <StormNet\NetReflectionStruct.h>
#include <StormNet\NetReflectionTypeDatabase.h>

#include <StormNet\NetReflection.h>

struct Struct
{
public:
  NET_REFL;
};
